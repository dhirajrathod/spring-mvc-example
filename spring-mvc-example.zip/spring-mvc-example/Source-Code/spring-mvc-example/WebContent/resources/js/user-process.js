
$(document).ready(function () {
    $('#please-wait').hide();
    $('#please-wait-data').hide();
    $("#export-pdf").hide();
    $("#export-excel").hide();
    $("#export-csv").hide();
    $("#export-print").hide();

    $("#submitForm").on('click', function () {
    	submitForm();
    });
    
    $("#jqGrid").jqGrid({
        url: 'getUsers',
        datatype: "json",
        colModel: [
            {label: 'Id', name: 'id'},
            {label: 'First Name', name: 'firstName'},
            {label: 'Last Name', name: 'lastName'},
            {label: 'Company Name', name: 'companyName'},
            {label: 'Gender', name: 'genderName'},
            {label: 'Hobbies', name: 'hobbiesName'},
            {label: 'Country', name: 'countryName'},
//            {label: 'Active', name: 'is_active', width: 60, formatter: isActiveBolean},
            {label: 'Created Date Time', name: 'createdDatetime'},
            {label: 'Updated Date Time', name: 'updatedDatetime'}
        ],
        viewrecords: true, // show the current page, data rang and total records on the toolbar
        rownumbers: true,
        width: 1100,
        height: 390,
        rowNum: 10,
        loadonce: true, // this is just for the demo
        pager: "#jqGridPager",
        forceFit: true,
        shrinkToFit: false,
        onInitGrid: function () {
            $("<div class='alert-info-grid'>No Record(s) Found</div>").insertAfter($(this).parent());
        },
        onSelectRow: function (id) {
            var grid = $("#jqGrid");
            var rowKey = grid.jqGrid('getGridParam', "selrow");
            var id = grid.jqGrid('getCell', rowKey, 'id');
            $('#please-wait').hide();
            $('#please-wait-data').hide();
        }, loadComplete: function (data) {
            var $this = $(this), p = $this.jqGrid("getGridParam");
            if (p.reccount === 0) {
                $this.hide();
                $this.parent().siblings(".alert-info-grid").show();
                $('#please-wait-data').hide();
                $('#please-wait').hide();
                $("#export-pdf").hide();
                $("#export-excel").hide();
                $("#export-csv").hide();
                $("#export-print").hide();
            } else {
                $this.show();
                $this.parent().siblings(".alert-info-grid").hide();
                $('#please-wait-data').hide();
                $('#please-wait').hide();
                $("#export-pdf").show();
                $("#export-excel").show();
                $("#export-csv").show();
                $("#export-print").show();
            }
        }
    });
    $("#jqGrid").hideCol("id");
    function isActiveBolean(cellvalue, options, rowObject) {
        if (cellvalue === 1 || cellvalue === "1") {
            return "Yes";
        } else if (cellvalue === 0 || cellvalue === "0") {
            return "No";
        }
    }
    function viewButtonShow(cellvalue, options, rowObject) {
        return '<input type="hidden" value="' + cellvalue + '" id="CellValue' + cellvalue + '"><button type="button"  id="viewCell' + cellvalue + '" class="btn btn-default " style="background-color:#2A3F54 !important;color:#fff !important;"><i class="fa fa-eye"></i></button>';
    }

    $("#export-pdf").on("click", function () {
        $("#jqGrid").hideCol("view");
        $("#jqGrid").jqGrid("exportToPdf", {
            title: 'User Details Exported to PDF',
            orientation: 'portrait',
            pageSize: 'A4',
            description: 'User Details List : ',
            customSettings: null,
            download: 'download',
            includeLabels: true,
            includeGroupHeader: true,
            includeFooter: true,
            fileName: "User-Details-Export-PDF.pdf"
        });
        $("#jqGrid").showCol("view");
    });
    $("#export-excel").on("click", function () {
        $("#jqGrid").hideCol("view");
        $("#jqGrid").jqGrid("exportToExcel", {
            includeLabels: true,
            includeGroupHeader: true,
            includeFooter: true,
            fileName: "User-Details-Export-Excel.xlsx",
            maxlength: 40 // maxlength for visible string data 
        });
        $("#jqGrid").showCol("view");
    });
    $("#export-csv").on("click", function () {
        $("#jqGrid").hideCol("view");
        $("#jqGrid").jqGrid("exportToCsv", {
            separator: ",",
            separatorReplace: "", // in order to interpret numbers
            quote: '"',
            escquote: '"',
            newLine: "\r\n", // navigator.userAgent.match(/Windows/) ?	'\r\n' : '\n';
            replaceNewLine: " ",
            includeCaption: true,
            includeLabels: true,
            includeGroupHeader: true,
            includeFooter: true,
            fileName: "User-Details-Export-CSV.csv",
            returnAsString: false
        });
        $("#jqGrid").showCol("view");
    });
    $("#export-print").on("click", function () {
        $("#jqGrid").hideCol("view");
        $("#jqGrid").jqGrid("exportToHtml", {
            includeLabels: true,
            includeGroupHeader: true,
            includeFooter: true,
            autoPrint: true
        });
        $("#jqGrid").showCol("view");
    });
    // activate the build in search with multiple option
    $('#jqGrid').navGrid("#jqGridPager", {
        search: true, // show search button on the toolbar
        add: false,
        edit: false,
        del: false,
        refresh: true
    },
            {}, // edit options
            {}, // add options
            {}, // back options
            {multipleSearch: true} // search options - define multiple search
    );
});

function submitForm() {
	$('#please-wait-data').show();
    $('#div-errors').hide();
    $('#div-server-errors').hide();
    $('#div-success').hide();
    var formName = "userForm";
    clearClientErrors(formName);
    onloadClearServerErrors();
    onloadClearServerSuccess();

    var firstName = $("#firstName").val();
    if (required(firstName)) {
        $("#" + $("#firstName").attr("id") + "-error").text("First Name" + requiredMessage);
    } else if (!isAlphaWithSpace(firstName)) {
        $("#" + $("#firstName").attr("id") + "-error").text("First Name" + alphaWithSpaceMessage);
    } else if (!isValidTillLength(firstName, 200)) {
        $("#" + $("#firstName").attr("id") + "-error").text("First Name" + validTillLengthMessage + "200 characters");
    }
    
    var lastName = $("#lastName").val();
    if (required(lastName)) {
        $("#" + $("#lastName").attr("id") + "-error").text("Last Name" + requiredMessage);
    } else if (!isAlphaWithSpace(lastName)) {
        $("#" + $("#lastName").attr("id") + "-error").text("Last Name" + alphaWithSpaceMessage);
    } else if (!isValidTillLength(lastName, 200)) {
        $("#" + $("#lastName").attr("id") + "-error").text("Last Name" + validTillLengthMessage + "200 characters");
    }

    var companyName = $("#companyName").val();
    if (required(companyName)) {
        $("#" + $("#companyName").attr("id") + "-error").text("Company Name" + requiredMessage);
    } else if (!isAlphaWithSpace(companyName)) {
        $("#" + $("#companyName").attr("id") + "-error").text("Company Name" + alphaWithSpaceMessage);
    } else if (!isValidTillLength(companyName, 200)) {
        $("#" + $("#companyName").attr("id") + "-error").text("Company Name" + validTillLengthMessage + "200 characters");
    }

    var country = $("#country").val();
    if (country === undefined || country === null || country === "" || country === 0 || country === "0") {
        $("#" + $("#country").attr("id") + "-error").text("Country" + requiredMessage);
    }
    
    var gender = $("input[name='gender']:checked").val();
    if (gender === undefined || gender === null || gender === "" || gender === 0 || gender === "0") {
        $("#gender1-error").text("Gender" + requiredMessage);
    }
    
    var hobbies = $("input[name='hobbies']:checked").val();
    if (hobbies === undefined || hobbies === null || hobbies === "" || hobbies === 0 || hobbies === "0") {
        $("#hobbies1-error").text("Hobbies" + requiredMessage);
    }

    var validate = isFormValidated(formName);
    if (validate) {
        $('#div-errors').hide();
        $('#div-server-errors').hide();
        $('#div-success').hide();
        $('#submitForm').hide();
        document.getElementById(formName).submit();
    } else {
        $('#div-success').hide();
        $('#div-errors').show();
        $('#div-server-errors').hide();
        $('#please-wait-data').hide();
    }
    
    
}

