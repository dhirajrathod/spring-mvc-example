
$(document).ready(function () {
    $('#please-wait-data').hide();
    $('#div-errors').hide();
	$("#errorOutput").hide();
	$("#successOutput").hide();
    
    $("#submitForm").on('click', function () {
    	submitForm();
    });
    
});

function submitForm() {
	$('#please-wait-data').show();
    $('#div-errors').hide();
    var formName = "arithmeticForm";
    clearClientErrors(formName);
    onloadClearServerErrors();
    onloadClearServerSuccess();

    var arithmeticValue = $("#arithmeticValue").val();
    if (required(arithmeticValue)) {
        $("#" + $("#arithmeticValue").attr("id") + "-error").text("Arithmetic Value" + requiredMessage);
    }

    var validate = isFormValidated(formName);
    if (validate) {
        $('#div-errors').hide();
        $('#submitForm').hide();
        processForm (arithmeticValue);
    } else {
        $('#div-errors').show();
        $('#please-wait-data').hide();
    }
}


function processForm (arithmeticValue) {
	$.ajax({
        url: "arithmetic-expression-process?arithmeticValue=" + encodeURIComponent(arithmeticValue),
        dataType: 'json',
        type: "GET",
        success: function (data, textStatus, jqXHR) {
                var successMessage = data;
                $('#please-wait-data').hide();
                $('#submitForm').show();
                $("#div-errors").hide();
                afterSuccess(successMessage);
        },
        error: function (data, textStatus, jqXHR) {
        	$("#div-errors").hide();
            $('#please-wait-data').hide();
            $('#submitForm').show();
            var errorMessage = "Sorry something went wrong. Please try again later!!";
            afterError(errorMessage);
        }
    });
}

function afterSuccess(message) {
	$("#errorOutput").hide();
	$("#successOutputText").html(message);
	$("#successOutput").show();
}

function afterError(message) {
	$("#successOutput").hide();
	$("#errorOutputText").html(message);
	$("#errorOutput").show();
	
}

