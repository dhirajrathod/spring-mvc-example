package com.spring.dao;

import java.util.List;

import com.spring.entity.UserDetails;

public interface UserDAO {
	public void save(UserDetails userDetails);

	public List<UserDetails> list();
}
