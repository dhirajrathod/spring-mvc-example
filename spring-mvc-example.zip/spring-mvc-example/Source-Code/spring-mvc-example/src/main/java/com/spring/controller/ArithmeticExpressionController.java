package com.spring.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ArithmeticExpressionController {

	@RequestMapping(value = "/arithmetic-expression", method = RequestMethod.GET)
	public String arithmeticExpression(Model model) {
		return "arithmetic-expression";
	}

	@RequestMapping(value = "/arithmetic-expression-process", method = RequestMethod.GET)
	@ResponseBody
	public String arithmeticExpression(@RequestParam String arithmeticValue) {
		String returnValue = StringUtils.EMPTY;
		try {
			ExpressionParser parser = new SpelExpressionParser();
			Object parsedValue = parser.parseExpression(arithmeticValue).getValue();
			if (parsedValue != null) {
				returnValue =  String.valueOf(parsedValue);
			}
		} catch (Exception e) {
		}
		return returnValue;
	}

}
