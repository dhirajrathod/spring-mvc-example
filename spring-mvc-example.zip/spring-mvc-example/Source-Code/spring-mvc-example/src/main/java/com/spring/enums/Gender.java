package com.spring.enums;

import org.apache.commons.lang3.StringUtils;

public enum Gender {

    MALE(1, "Male"),
    FEMALE(2, "Female");

    private final int id;
    private final String value;

    Gender(int id, String value) {
        this.id = id;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static Gender getGenderById(int id) {
        for (Gender e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return null;
    }

    public static Gender getGenderByValue(String value) {
        for (Gender e : values()) {
            if (StringUtils.isNotEmpty(value) && value.equalsIgnoreCase(e.value)) {
                return e;
            }
        }
        return null;
    }

}
