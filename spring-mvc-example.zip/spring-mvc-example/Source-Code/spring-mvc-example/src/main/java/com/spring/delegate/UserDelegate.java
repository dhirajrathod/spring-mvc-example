package com.spring.delegate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.UserDAOImpl;
import com.spring.entity.UserDetails;

@Service
public class UserDelegate {

	@Autowired
	UserDAOImpl userDAOImpl = new UserDAOImpl();

	@Transactional
	public void save(UserDetails userDetails) {
		userDAOImpl.save(userDetails);
	}

	@Transactional
	public List<UserDetails> list() {
		return userDAOImpl.list();
	}
}
