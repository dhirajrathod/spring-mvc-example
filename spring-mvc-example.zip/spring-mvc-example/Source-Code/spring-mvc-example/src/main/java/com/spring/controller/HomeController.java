package com.spring.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.commons.ParseJSON;
import com.spring.delegate.UserDelegate;
import com.spring.entity.UserDetails;
import com.spring.enums.Country;
import com.spring.enums.Gender;
import com.spring.enums.Hobbies;

@Controller
public class HomeController {

	@Autowired
	private UserDelegate userDelegate;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String loadInitial() {
		return "initial";
	}

	@RequestMapping(value = "/user-details", method = RequestMethod.GET)
	public String loadUser(ModelMap map) {
		map.addAttribute("userDetails", new UserDetails());
		return "home";
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String saveUserDetails(@ModelAttribute(value = "userDetails") UserDetails userDetails, BindingResult result,
			Model model) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		userDetails.setCreatedDatetime(date);
		userDetails.setUpdatedDatetime(date);

		userDelegate.save(userDetails);
		model.addAttribute("successMessage", "User Details Added Successfully");
		return "home";
	}

	@RequestMapping(value = "/getUsers", method = RequestMethod.GET)
	@ResponseBody
	public String getUsers() {
		String responseJSON = StringUtils.EMPTY;
		List<UserDetails> userDetailsList = userDelegate.list();

		userDetailsList.forEach(userDetails -> {
			Gender gender = Gender.getGenderById(userDetails.getGender());
			String genderName = StringUtils.EMPTY;
			if (gender != null) {
				genderName = gender.getValue();
			}
			userDetails.setGenderName(genderName);
			Country country = Country.getCountryById(userDetails.getCountry());
			String countryName = StringUtils.EMPTY;
			if (country != null) {
				countryName = country.getValue();
			}
			userDetails.setCountryName(countryName);

			String hobbiesArray[] = userDetails.getHobbies().split(",");
			String hobbiesName = StringUtils.EMPTY;
			for (String hobbiesDetails : hobbiesArray) {
				int hobbiesId = Integer.parseInt(hobbiesDetails);
				Hobbies hobbies = Hobbies.getHobbiesById(hobbiesId);
				if (hobbies != null) {
					hobbiesName += hobbies.getValue() + ", ";
				}
			}
			userDetails.setHobbiesName(hobbiesName);
		});

		responseJSON = ParseJSON.objectToJSON(userDetailsList);
		return responseJSON;
	}
}
