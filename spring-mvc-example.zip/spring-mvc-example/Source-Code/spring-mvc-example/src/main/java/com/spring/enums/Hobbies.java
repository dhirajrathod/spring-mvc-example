package com.spring.enums;

import org.apache.commons.lang3.StringUtils;

public enum Hobbies {

    CRICKET(1, "Cricket"),
    FOOTBALL(2, "Football"),
    OTHER(3, "Other");

    private final int id;
    private final String value;

    Hobbies(int id, String value) {
        this.id = id;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static Hobbies getHobbiesById(int id) {
        for (Hobbies e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return null;
    }

    public static Hobbies getHobbiesByValue(String value) {
        for (Hobbies e : values()) {
            if (StringUtils.isNotEmpty(value) && value.equalsIgnoreCase(e.value)) {
                return e;
            }
        }
        return null;
    }

}
