package com.spring.enums;

import org.apache.commons.lang3.StringUtils;

public enum Country {

    INDIA(1, "India"),
    US(2, "US"),
    ENGLAND(3, "England"),
    SRI_LANKA(4, "Sri Lanka");

    private final int id;
    private final String value;

    Country(int id, String value) {
        this.id = id;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static Country getCountryById(int id) {
        for (Country e : values()) {
            if (e.id == id) {
                return e;
            }
        }
        return null;
    }

    public static Country getCountryByValue(String value) {
        for (Country e : values()) {
            if (StringUtils.isNotEmpty(value) && value.equalsIgnoreCase(e.value)) {
                return e;
            }
        }
        return null;
    }

}
