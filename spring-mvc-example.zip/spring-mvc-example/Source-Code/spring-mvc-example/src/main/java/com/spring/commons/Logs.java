package com.spring.commons;

import org.apache.log4j.Logger;

public class Logs {

    private final static Logger DATABASE_LOGGER = Logger.getLogger("database");
    private final static Logger INITIAL_LOGGER = Logger.getLogger("admin");
    private final static Logger SERVICE_LOGGER = Logger.getLogger("home");

    public static Logger getDatabaseLoggers() {
        return DATABASE_LOGGER;
    }

    public static Logger getInitialsLoggers() {
        return INITIAL_LOGGER;
    }

    public static Logger getServiceLoggers() {
        return SERVICE_LOGGER;
    }

}
