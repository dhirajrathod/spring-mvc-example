Execute Database file in Mysql Server or Mysql Workbench available in Database Folder named as dataabse.sql.

Once done now change the database configuration in file spring-mvc-example\WebContent\WEB-INF\jdbc.properties